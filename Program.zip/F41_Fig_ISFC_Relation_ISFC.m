clear;clc;

%% �԰�ֺ���һ��ISFCɢ��ͼ
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_178Subj CorrMat;%4*178*34980
CorrMat_LOT = squeeze(mean(CorrMat,2));%LOT:leave one out;

load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_HalfSubj CorrMat;%4*[1:89]*34980
CorrMat_Half1 = CorrMat;

load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_HalfSubj_2 CorrMat;%4*[90:178]*34980
CorrMat_Half2 = CorrMat;

CorrMat_Half(:,[1:89],:) = CorrMat_Half1;CorrMat_Half(:,[90:178],:) = CorrMat_Half2;
CorrMat_Half = squeeze(mean(CorrMat_Half,2));

figure('Position',[100 20 800 800]);box on; hold on;
x = 4; %%�޸�1��2��3��4�任��Ӱ
scatter(CorrMat_LOT(x,:),CorrMat_Half(x,:),'k.');
R = corr(squeeze(CorrMat_LOT(x,:))',squeeze(CorrMat_Half(x,:))');

set(gca, 'color', 'white', 'LineWidth',2, 'fontsize',18, 'fontname', 'arial', 'fontweight', 'bold');
axis([-0.4 0.9 -0.4 0.9]);
ylim([-0.4,0.9]);
set(gca,'YTick',[-0.4:0.1:0.9]);
xlim([-0.4,0.9]);
set(gca,'XTick',[-0.4:0.1:0.9]);
set(gca,'XTickLabel',{'','-0.3','-0.2','-0.1','0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9'});
text(0.59,0.85,-1, ['R = ', num2str(R, '%3.4f')],'FontSize',24, 'fontname', 'times new roman', 'fontweight', 'bold');
text(0.0987,0.935,-1, 'Forth Run','FontSize',24, 'fontname', 'times new roman', 'fontweight', 'bold');
% text(0.0966,0.935,-1, 'Third Run','FontSize',24, 'fontname', 'times new roman', 'fontweight', 'bold');
% text(0.0798,0.935,-1, 'Second Run','FontSize',24, 'fontname', 'times new roman', 'fontweight', 'bold');
% text(0.1112,0.935,-1, 'First Run','FontSize',24, 'fontname', 'times new roman', 'fontweight', 'bold');
set(gca,'fontweight', 'bold','Linewidth',2) 
ylabel('Group-based ISFCs', 'FontSize',24, 'fontname', 'times new roman', 'fontweight', 'bold'); 
xlabel('Leave-one-out-based ISFCs', 'FontSize',24, 'fontname', 'times new roman', 'fontweight', 'bold'); 
