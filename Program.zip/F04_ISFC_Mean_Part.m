%F01 �Ĳ���ӰISFC��ƽ��
clear;clc;
ROI_NUM = 264;

%%
%��ISFC�ĶԳ���
%%ISFC
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_12Part_178Subj;


%�ĸ���Ӱ�ֱ���ʾ�������졣����һ����ʾ�������ܵľ����ˣ��ֿ�������࣬�����ڲ�һ�µĽ��
% CorrAll = squeeze(CorrAll(1,:,:)); %1/2/3/4����4����Ӱ
CorrAllM = squeeze(mean(CorrMat264,2)); CorrAll = squeeze(mean(CorrAllM, 1)); 
%%
%��AP����Ļ���
load D:\brainFingerprint\code\ISFCwork\Results\AP6Clus210331.mat
NetNo = ROI_264;
NET_NUM = length(unique(NetNo)); 
ROI_No_New =[];

for i=1:NET_NUM
   NetNoTemp =  find(NetNo==i);%id
   len = length(NetNoTemp);
   halfLen = round(len/2);
   NetNoTemp1 = NetNoTemp(1:halfLen);
   NetNoTemp2 = NetNoTemp(halfLen+1:len);
   tempMatrix1 = CorrAll(NetNoTemp1,NetNoTemp1);%��������Ϊ����
   tempMatrix2 = CorrAll(NetNoTemp2,NetNoTemp2);
   sumColumn1 = sum(tempMatrix1);%value
   sumColumn2 = sum(tempMatrix2);
    
   [sumColumn1,id1]  = sort(sumColumn1);
   [sumColumn2,id2]  = sort(sumColumn2,'descend');
   NetNoTempNew = NetNoTemp1(id1);
   NetNoTempNew = [NetNoTempNew;NetNoTemp2(id2)];
   ROI_No_New = [ROI_No_New;NetNoTempNew];
end

CorrAll = CorrAll(ROI_No_New, ROI_No_New); 
figure(1); imagesc(CorrAll);   colorbar(); caxis([-0.3,1]);hold on;
colorbar( 'FontSize',10, 'fontname', 'arial','YTick',[-0.3:0.1:1]);%,'YTickLabel',{'-0.1','0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1'}
%%
%������ָ���
NetNoUnique = unique(NetNo); NetTmp = 1; 
for Count = 1 : ROI_NUM-1
    if(NetTmp < length(NetNoUnique))
        if(NetNo(ROI_No_New(Count)) == NetNoUnique(NetTmp) && NetNo(ROI_No_New(Count+1)) == NetNoUnique(NetTmp+1))
            Value = Count + 0.5;
            plot([0:264], Value * ones(1,265), 'Color',[0.7 0.7 0.7], 'linewidth', 1);
            plot(Value * ones(1,265), [0:264], 'Color',[0.7 0.7 0.7], 'linewidth', 1);
            NetTmp = NetTmp + 1;
        end
    end
end

axis off;
text(-25.356,25.9474,'SMN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-26.2695,78.23,'DMN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-25.8581,131.7126,'CON','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-25.9987,177.4411,'VisN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-34.9867,217.77,'LangN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-23.5763,249.0236,'FPN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');

text(14.8929,271.22,'SMN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(67.8692,271.22,'DMN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(119.5028,271.22,'CON','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(165.56,271.22,'VisN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(200.1253,271.22,'LangN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(238.8837,271.22,'FPN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');