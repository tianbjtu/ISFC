%% ��ȡƬ��
OUTDIR = 'D:\brainFingerprint\code\ISFCwork\Results\';


load(strcat(OUTDIR,'Movie1_TS264'));%TS
tmp = TS;
TS = tmp(:,[1:239],:);
save(strcat(OUTDIR,'Movie1_TS264-Part1'),'TS');
TS = tmp(:,[240:454],:);
save(strcat(OUTDIR,'Movie1_TS264-Part2'),'TS');
TS = tmp(:,[455:637],:);
save(strcat(OUTDIR,'Movie1_TS264-Part3'),'TS');

load(strcat(OUTDIR,'Movie2_TS264'));%TS
tmp = TS;
TS = tmp(:,[1:222],:);
save(strcat(OUTDIR,'Movie2_TS264-Part1'),'TS');
TS = tmp(:,[223:476],:);
save(strcat(OUTDIR,'Movie2_TS264-Part2'),'TS');
TS = tmp(:,[477:721],:);
save(strcat(OUTDIR,'Movie2_TS264-Part3'),'TS');

load(strcat(OUTDIR,'Movie3_TS264'));%TS
tmp = TS;
TS = tmp(:,[1:175],:);
save(strcat(OUTDIR,'Movie3_TS264-Part1'),'TS');
TS = tmp(:,[176:354],:);
save(strcat(OUTDIR,'Movie3_TS264-Part2'),'TS');
TS = tmp(:,[355:553],:);
save(strcat(OUTDIR,'Movie3_TS264-Part3'),'TS');

load(strcat(OUTDIR,'Movie4_TS264'));%TS
tmp = TS;
TS = tmp(:,[1:228],:);
save(strcat(OUTDIR,'Movie4_TS264-Part1'),'TS');
TS = tmp(:,[229:453],:);
save(strcat(OUTDIR,'Movie4_TS264-Part2'),'TS');
TS = tmp(:,[454:704],:);
save(strcat(OUTDIR,'Movie4_TS264-Part3'),'TS');

    
