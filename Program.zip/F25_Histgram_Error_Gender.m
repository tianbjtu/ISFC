clear;clc;
load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Gender; %���� R:100*4*4,MeanR 4*4
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Gender_HighICCCorr;%ICC>0.3��Corr��
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Gender_SignCorr;%������Corr��

MeanR = roundn(MeanR,-2);
M1_test= [MeanR(1,1), MeanR(1,2),MeanR(1,3),MeanR(1,4)];
M2_test= [MeanR(2,1), MeanR(2,2),MeanR(2,3),MeanR(2,4)];
M3_test= [MeanR(3,1), MeanR(3,2),MeanR(3,3),MeanR(3,4)];
M4_test= [MeanR(4,1), MeanR(4,2),MeanR(4,3),MeanR(4,4)];

a = [M1_test; M2_test; M3_test; M4_test];
figure('Position',[100 100 650 500]);
scrsz = get(0, 'ScreenSize');
%set(gcf, 'color', 'white'); set(gca, 'color', 'white', 'LineWidth',2, 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
bar(a, 'grouped','BarWidth',1);%,5
% h = bar(a, 'grouped');
% set(h,'BarWidth',1.5);
 
set(gca,'YLim', [0,0.9], 'XTickLabel',{'M1', 'M2', 'M3', 'M4'},'color', 'white', 'LineWidth',2, 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
ylabel('Classification Rate','fontsize',18, 'fontname', 'times new roman', 'fontweight', 'bold');
set(gca, 'Ytick', [0:0.1:0.9]);
set(gca, 'YTickLabel', {'0','10%','20%','30%','40%','50%','60%','70%','80%','90%'});


for Mov1 = 1:4
    for Mov2 = 1:4
        Temp = std(R(:,Mov1,Mov2));
        e(Mov1,Mov2) = Temp;
    end
end

%e = [0.0198, 0.0124, 0.0096, 0.0112; 0.0875, 0.0990, 0.1034, 0.0939];
hold on
numgroups = size(a, 1); 
numbars = size(a, 2); 
groupwidth = min(0.8, numbars/(numbars+1.5));
for i = 1:numbars
      % Based on barweb.m by Bolu Ajiboye from MATLAB File Exchange
      x = (1:numgroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*numbars);  % Aligning error bar with individual bar
      errorbar(x, a(:,i), e(:,i), 'k', 'linestyle', 'none', 'lineWidth', 1);
end
box off;
legend('Mi-M1','Mi-M2','Mi-M3','Mi-M4', 'Location', 'northEastOutside');%,[0.875238097324258 0.836333316485087 0.128571426485266 0.170999995231628]
legend('boxoff');

for i =1:4
    tmp1 = squeeze(R(:,i,i));
    for j = 1:4
        [H,P] = ttest2(tmp1,R(:,i,j));
        P_value(i,j) = P;
    end
end

