clear;clc;
%%
% % %Fig4��A�����Ա�Ԥ�����
% %load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR160ROI_Gender;%��Χ����[0,0.9]
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR160ROI_Strength %��Χ����[0,0.45]
% %load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR160ROI_CrystalIQ %��Χ����[0,0.45]
% XVarNames = {'Mov1','Mov2','Mov3','Mov4'};
% matrixplot(MeanR, 'XVarNames', XVarNames, 'YVarNames', XVarNames, 'FillStyle', 'Fill', 'ColorBar', 'on');

%% ��16�����д����Ե�AUCֵ����strengthû�ж�Ӧ�ģ�������
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR160ROI_Gender;
% load D:\brainFingerprint\code\ISFCwork\Results\SubjInfo178_222Label_200507;
% 
% LabelTmp = SubjInfo(:, 2);
% SubjNoUse = find(LabelTmp ~= -9999); Label = LabelTmp(SubjNoUse); SampleSize = length(Label);
% % Predicted1 = squeeze(Predicted(1,2,1,:));%Predicted 100*4*4*178 ѡ��ڼ��ֲ����Ǹ���R��100*4*4��ѡ�ġ�
%��ʵR
% 0.77 0.66 0.63 0.66
% 0.61 0.76 0.63 0.63
% 0.64 0.68 0.79 0.64
% 0.71 0.58 0.69 0.83


% %axis([0 1 0 1]);
% No = [1,5,7,18,1,9,3,10,7,13,14,7,13,1,2,3];
% for Mov1 = 1:4
%     for Mov2 = 1:4
%         Predicted1 = squeeze(Predicted(No((Mov1-1)*4+Mov2),Mov1,Mov2,:));
%         auc(Mov1,Mov2) = f_AUC(Label,Predicted1);
%     end
% end
% XVarNames = {'Mov1','Mov2','Mov3','Mov4'};
% matrixplot(auc, 'XVarNames', XVarNames, 'YVarNames', XVarNames, 'FillStyle', 'Fill', 'ColorBar', 'on');

%% ��ROC���� Fig4��C�����ĸ��д����Եġ�
load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Gender;
load D:\brainFingerprint\code\ISFCwork\Results\SubjInfo178_222Label_200507;

LabelTmp = SubjInfo(:, 2);
SubjNoUse = find(LabelTmp ~= -9999); Label = LabelTmp(SubjNoUse); SampleSize = length(Label);
Predicted1 = squeeze(Predicted(3,1,1,:));%Predicted 100*4*4*178 % %3-m1-m1;44-m1-m2;
%axis([0 1 0 1]);
figure('Position',[200 20 800 800]);box on; hold on;
plotroc(Label',Predicted1');
% xlabel('False Positive Rate', 'FontSize',19, 'fontname', 'times new roman', 'fontweight', 'bold');
% ylabel('True Positive Rate', 'FontSize',19, 'fontname', 'times new roman', 'fontweight', 'bold'); 
auc = f_AUC(Label,Predicted1);
% title(strcat('ROC Curve (AUC =',num2str(auc,'%0.2f'),')'),'fontsize',19, 'fontname', 'times new roman', 'fontweight', 'bold');
title(strcat('AUC =',num2str(auc,'%0.2f')),'fontsize',19, 'fontname', 'times new roman', 'fontweight', 'bold');
box on;
set(gca,'XTick',[0 : 0.1: 1]); 
set(gca,'XTickLabel',[0 : 0.1 : 1]);

set(gca, 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold','Linewidth',2);

% %% ����״ Fig4��E��
% MAX_Y = 1600;
% 
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_Perm5000_PLSR264ROI_Gender R ; %5000��4*4��ֻȡ���꣨1,1������ǧ������
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Gender MeanR;
% 
% %��ʵR
% %     0.7800    0.6800    0.7000    0.7300
% %     0.6100    0.7500    0.6200    0.6200
% %     0.6400    0.6500    0.8000    0.6500
% %     0.6800    0.6900    0.6300    0.8400
% % %1-m1-m1;5-m1-m2;7-m1-m3;18-m1-m4
% Rtrue = 0.78;
% R_Perm = squeeze(R(:,1,1));
% Rmax = max(R_Perm);
% Rmin = min(R_Perm);
% 
% % A = [-0.22 : 0.02 : 0.52];
% A = [0.32 : 0.03 : 0.86]; %%-----
% 
% for Tmp = 1 : length(A)
%     ACC_YY(Tmp) = sum ((R_Perm>=A(Tmp)-0.03) .* (R_Perm<A(Tmp))); %%-----
% end    
% 
% figure('Position',[100 20 800 800]);box on; hold on;grid on; axis([0.32 0.86 0 MAX_Y]); 
% set(gcf, 'color', 'white'); 
% set(gca, 'color', 'white', 'LineWidth',2, 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% 
% h = bar(A-0.015, ACC_YY, 0.9, 'FaceColor',[0.55 0.55 0.55], 'LineWidth',2);
% set(gca,'XTick',A); 
% set(gca,'XTickLabel',[]);
% set(gca,'YTick',[0 : 100: MAX_Y]); 
% set(gca,'YTickLabel',[0 : 100 : MAX_Y]);
% % for Tmp = 1 : length(A)
% %     if ACC_YY(Tmp)>=100
% %         text(A(Tmp)-0.027, ACC_YY(Tmp)+19, num2str(ACC_YY(Tmp)), 'fontsize',9, 'fontname', 'arial', 'fontweight', 'bold'); % 'bold'
% %     elseif ACC_YY(Tmp)>0
% %         text(A(Tmp)-0.02, ACC_YY(Tmp)+19, num2str(ACC_YY(Tmp)), 'fontsize',9, 'fontname', 'arial', 'fontweight', 'bold');
% %     end
% % end
% 
% for Tmp = 1 : 2: length(A)
%     for i = [0.38 : 0.03 : 0.89]
%         if abs(A(Tmp)- i) < 10e-6
%             %data = A(Tmp)*100;
%             data = A(Tmp);
%             %str = [num2str(data,'%4.2f'),]
%             str = strcat(num2str(data*100,'%4.0f'),'%');
%             text(A(Tmp)-0.016,-35, str, 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
%         end
%     end
% end
% 
%     
% %     if(A(Tmp)<-0.03)
% %         text(A(Tmp)-0.015, -2, strcat('R',num2str(A(Tmp))), 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% %     elseif (A(Tmp)>0.03)
% %         text(A(Tmp)-0.015, -2, strcat('R+',num2str(A(Tmp))), 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% %     else        
% %         text(A(Tmp)-0.005, -2, 'R', 'fontsize',12, 'fontname', 'arial', 'fontweight', 'bold');
% %     end
% 
% plot(Rtrue*ones(1,length(0.2:0.1:MAX_Y-0.2)), [0.2:0.1:MAX_Y-0.2], 'r.', 'LineWidth',2)
% 
% %xlabel('Correlations Based on 500 Permutations', 'FontSize',19, 'fontname', 'arial', 'fontweight', 'bold', 'Position', [-0.6, -3.9]);
% ylabel('Number of Classification Rates', 'FontSize',19, 'fontname', 'times new roman', 'fontweight', 'bold'); 
% %xlabel('Correlation between the Estimated and Permuted Chronological Age', 'FontSize',16, 'fontname', 'arial', 'fontweight', 'bold'); 

% 
% %% P-value
% clear;clc;
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_Perm5000_PLSR264ROI_Gender R; %5000��4*4��ֻȡ���꣨1,1������ǧ������
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Gender MeanR;
% Rture = [0.39,0.10,0.24,0.14,0.16,0.27,0.15,0.12,0.29,0.22,0.47,0.30,0.18,0.18,0.29,0.34];
% 
% for mov1 = 1:4
%     for mov2 = 1:4
%         A = squeeze(R(:,mov1,mov2));
%         N_High = sum(sum(A>MeanR(mov1,mov2))');
%         P_Value(mov1,mov2) = (1+N_High)/5001
%     end
% end
