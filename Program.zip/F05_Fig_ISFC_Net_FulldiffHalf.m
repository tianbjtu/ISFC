%% �������ȥƬ��ISFC
clear;clc;
ROI_NUM = 264;

%% FullTS ISFC
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_178Subj.mat; %CorrMat264
CorrAllM = squeeze(mean(CorrMat264,2)); CorrMatMean1 = squeeze(mean(CorrAllM, 1)); 

%% Half1
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_HalfSubj; %CorrMat264
temp(:,[1:89],:,:) = CorrMat264;
%% Half2
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_HalfSubj_2; %CorrMat264
temp(:,[90:178],:,:) = CorrMat264;

CorrAllM_Half = squeeze(mean(temp,2)); CorrMatMean2 = squeeze(mean(CorrAllM_Half, 1)); 

%% ��AP����Ļ���
load D:\brainFingerprint\code\ISFCwork\Results\AP6Clus210331.mat
NetNo = ROI_264;
NET_NUM = length(unique(NetNo));
CorrNetMean_Full = zeros(NET_NUM, NET_NUM);
CorrNetMean_Half = zeros(NET_NUM, NET_NUM);
for Tmp1 = 1 : NET_NUM
    for Tmp2 = 1 : Tmp1
        NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);         
        Mat = zeros(ROI_NUM,ROI_NUM); 
        Mat(NetNo1, NetNo2) = 1; Mat(NetNo2,NetNo1) = 1;
        FEAT_NO = find(tril(Mat)); 

        Tmp4 = CorrMatMean1;
        Tmp3 = Tmp4(FEAT_NO);% 178*������
        CorrNetMean_Full(Tmp1,Tmp2) = mean(Tmp3(:));
        
        Tmp5 = CorrMatMean2;
        Tmp6 = Tmp5(FEAT_NO);% 178*������
        CorrNetMean_Half(Tmp1,Tmp2) = mean(Tmp6(:));
    end
end
CorrNetMean_Full = roundn(CorrNetMean_Full,-2);
CorrNetMean_Half = roundn(CorrNetMean_Half,-2);

XVarNames = {'SMN','DMN','CON','VisN','ALN','FPN'};
matrixplot(CorrNetMean_Full-CorrNetMean_Half, 'XVarNames',XVarNames,'YVarNames',XVarNames,'ColorBar','on'); 