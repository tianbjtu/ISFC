clear;clc;
ROI_NUM = 264; 
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_HalfSubj_2.mat; 


%% ISFC 
for Tmp = 1 : size(CorrMat, 3)
    [ICC_ISFC(Tmp), LB_ISFC(Tmp), UB_ISFC(Tmp), F_ISFC(Tmp), df1, df2, p_ISFC(Tmp)] = f_ICC(squeeze(CorrMat(:,:,Tmp))', '1-1', 0.05, 0);
end

ICC_NSFC_Mat = zeros(ROI_NUM, ROI_NUM);
LB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM);
UB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM);
Count = 0;
for Tmp1 = 1 : ROI_NUM  %1:264
    for Tmp2 =  Tmp1 : ROI_NUM  %1:264 
        Count = Count + 1;
        ICC_ISFC_Mat(Tmp1, Tmp2) = ICC_ISFC(Count);
        ICC_ISFC_Mat(Tmp2, Tmp1) = ICC_ISFC(Count);
        LB_ISFC_Mat(Tmp1, Tmp2) = LB_ISFC(Count);
        LB_ISFC_Mat(Tmp2, Tmp1) = LB_ISFC(Count);
        UB_ISFC_Mat(Tmp1, Tmp2) = UB_ISFC(Count);
        UB_ISFC_Mat(Tmp2, Tmp1) = UB_ISFC(Count);
    end
end

save D:\brainFingerprint\code\ISFCwork\Results\ICC_ISFC_HalfSample_2 ICC_ISFC LB_ISFC UB_ISFC ICC_ISFC_Mat LB_ISFC_Mat UB_ISFC_Mat;
% ICC_ISFC LB_ISFC UB_ISFC��1*25600����
% ICC_ISFC_Mat LB_ISFC_Mat UB_ISFC_Mat��160*160����


%% Network
%--���������network��ICC�ľ�ֵ��ÿ������21����ֵ��
%--���������������������õ���ICC_ISFC_Mat
%--���NetMean_ICC_Mat������NetMean���ICC

%��AP����Ļ���
load D:\brainFingerprint\code\ISFCwork\Results\AP6Clus210331.mat
NetNo = ROI_264;
NET_NUM = length(unique(NetNo)); 
ICC_ISFC_Vector = ICC_ISFC_Mat(:);
LB_ISFC_Vector = LB_ISFC_Mat(:);
UB_ISFC_Vector = UB_ISFC_Mat(:);
for Tmp1 = 1 : NET_NUM
    for Tmp2 = 1 : Tmp1
        NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);
        Mat = zeros(ROI_NUM, ROI_NUM); 
        Mat(NetNo1, NetNo2) = 1; Mat(NetNo2, NetNo1) = 1; 
        FEAT_NO = find(tril(Mat));       
        
        ICC_NetMean_Mat(Tmp1, Tmp2) = mean(ICC_ISFC_Vector(FEAT_NO));
        LB_Net(Tmp1, Tmp2) = mean(LB_ISFC_Vector(FEAT_NO));
        UB_Net(Tmp1, Tmp2) = mean(LB_ISFC_Vector(FEAT_NO));
    end
end

save D:\brainFingerprint\code\ISFCwork\Results\ICC_Net_HalfSample_2 ICC_NetMean_Mat LB_Net UB_Net;
% ICC_NetMean_Mat��NET_NUM * NET_NUM����
% LB_Net UB_Net��ͬ��


%% Global
ICC_Glob = mean(ICC_ISFC);
LB_Glob = mean(LB_ISFC);
UB_Glob = mean(UB_ISFC);
save D:\brainFingerprint\code\ISFCwork\Results\ICC_Glob_HalfSample_2 ICC_Glob LB_Glob UB_Glob;
% ICC_Glob LB_Glob UB_Glob���Ǳ���