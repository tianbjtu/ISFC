clear;clc;

%% ICC��ISFC��ϵͼ
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_178Subj CorrMat;
CorrMat = squeeze(mean(CorrMat,1));CorrMat = squeeze(mean(CorrMat,1));
load D:\brainFingerprint\code\ISFCwork\Results\ICC_ISFC_FullTS ICC_ISFC;

%%����ISFC��ICC���԰�ISFC�Ĵ�С����
[SortedISFC,Pos] = sort(abs(CorrMat),'descend');
New_ICC_ISFC = ICC_ISFC(Pos);

%%��100����ֵ�����ߣ�ǰ�ٷ�֮���ľ�ֵ
for i = 1:100
    %   ȡֵ
    temp = round(34980/100*i);
    MeanICC(i) = mean(New_ICC_ISFC([1:temp]));
end

figure('Position',[10 10 1040 405]);box on;  hold on;
set(gca, 'color', 'white', 'LineWidth',1.5, 'fontsize',13, 'fontname', 'arial', 'fontweight', 'bold');
x=1:1:100;
plot(x,MeanICC,'-ok','MarkerSize',6,'MarkerFaceColor','k','MarkerEdgeColor','k','LineWidth',1.5');
axis([0 101 0.10 0.45]);
set(gca,'XTick',0:2:100);
set(gca,'XTicklabel',{'0','','','','','10%','','','','','20%','','','','','30%','','','','','40%','','','','','50%','','','','','60%','','','','','70%','','','','','80%','','','','','90%','','','','','100%'});
set(gca,'YTicklabel',{'0.10','0.15','0.20','0.25','0.30','0.35','0.40','0.45'});
xlabel('Percentage of ISFCs', 'FontSize',17, 'fontname', 'times new roman', 'fontweight', 'bold');
ylabel('Mean ICC', 'FontSize',17, 'fontname', 'times new roman', 'fontweight', 'bold'); 