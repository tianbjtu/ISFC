%ISFC����Net
clear;clc;
ROI_NUM = 264;

%ISFC
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_178Subj.mat; % CorrMat 4*178*25600 CorrMat160 4*178*160*160

% CorrMatMean = squeeze(mean(CorrMat160,2));
CorrAllM = squeeze(mean(CorrMat264,2)); CorrMatMean = squeeze(mean(CorrAllM, 1)); 
MovNum = size(CorrMat264,1);

%% ��AP����Ļ���
load D:\brainFingerprint\code\ISFCwork\Results\AP6Clus210331.mat
NetNo = ROI_264;
NET_NUM = length(unique(NetNo));

%% ���е�Ӱһ������缶ƽ��
% CorrNetMean = zeros(NET_NUM, NET_NUM);
% for Tmp = 1 : NET_NUM
%     for Tmp2 = 1 : Tmp                     
%         A = CorrMat160(:, :, find(NetNo==Tmp| NetNo==Tmp2), find(NetNo==Tmp2|NetNo==Tmp));   
%         CorrNetMean(Tmp, Tmp2) = mean(A(:));
%     end
% end

%%
%ÿ����Ӱ�ֿ������缶ƽ�� 6*6ȫ������
% CorrNetMean = zeros(NET_NUM, NET_NUM);
% for Tmp = 1 : NET_NUM
%     for Tmp2 = 1 : NET_NUM                     
%         A = CorrMat160(1, :, find(NetNo==Tmp), find(NetNo==Tmp2));   
%         CorrNetMean(Tmp, Tmp2) = mean(A(:));
%     end
% end

%% ȫ������������,�㷨1 �������㷨���һ��
% CorrNetMean = zeros(NET_NUM, NET_NUM);
% for Tmp = 1 : NET_NUM
%     for Tmp2 = 1 : Tmp
%         if Tmp == Tmp2
%             A = CorrMat160(1, :, find(NetNo==Tmp), find(NetNo==Tmp2)); 
%             CorrNetMean(Tmp, Tmp2) = mean(A(:));
%         else
%             A = CorrMat160(1, :, find(NetNo==Tmp), find(NetNo==Tmp2));   
%             B = CorrMat160(1, :, find(NetNo==Tmp2), find(NetNo==Tmp)); 
%             C = [A(:);B(:)];
%             CorrNetMean(Tmp, Tmp2) = mean(C(:));
%         end
%     end
% end

%% ȫ�����������ǣ���F02_useA03dataһ�¡�
CorrNetMean = zeros(NET_NUM, NET_NUM);
for Tmp1 = 1 : NET_NUM
    for Tmp2 = 1 : Tmp1
        NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);         
        Mat = zeros(ROI_NUM,ROI_NUM); 
        Mat(NetNo1, NetNo2) = 1; Mat(NetNo2,NetNo1) = 1;
        FEAT_NO = find(tril(Mat)); 
       
%         Tmp = squeeze(CorrMatMean(4,:,:));%Tmp 178*25600,�޸������1-2/3/4��ò�ͬ��Ӱ��ͼ
        Tmp = CorrMatMean;
        Tmp3 = Tmp(FEAT_NO);% 178*������
        CorrNetMean(Tmp1,Tmp2) = mean(Tmp3(:));
    end
end

% %%
% %�����ֵ������ƽ��
% load E:\brainFingerprint\code\FCReliability\Results\NSFCdiffPartNSFCOriginal.mat

%��AP����Ļ���
% load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
% NetNo = ROI_160;
% NET_NUM = length(unique(NetNo));
% CorrNetMean = zeros(NET_NUM, NET_NUM);
% for Tmp = 1 : NET_NUM
%     for Tmp2 = 1 : Tmp                     
%         A = CorrAllTmp(NetNo==Tmp, NetNo==Tmp2);
%         if(Tmp == Tmp2)
%             CorrNetMean(Tmp, Tmp2) = sum(A(:))/(length(find(NetNo==Tmp))^2 - length(find(NetNo==Tmp)));
%         else     
%             CorrNetMean(Tmp, Tmp2) = mean(A(:));
%         end
%     end
% end
% CorrNetMean = roundn(CorrNetMean, -2);
%%
XVarNames = {'SMN','DMN','CON','VisN','ALN','FPN'};
matrixplot(CorrNetMean, 'XVarNames',XVarNames,'YVarNames',XVarNames,'ColorBar','on'); 