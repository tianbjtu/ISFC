clear;clc;
ROI_NUM = 264;

%% Fig2(A) 
load D:\brainFingerprint\code\ISFCwork\Results\ICC_ISFC_FullTS.mat;

%%
%��AP����Ļ���
load D:\brainFingerprint\code\ISFCwork\Results\AP6Clus210331.mat
NetNo = ROI_264;
NET_NUM = length(unique(NetNo)); 
ROI_No_New =[];

for i=1:NET_NUM
   NetNoTemp =  find(NetNo==i);%id
   len = length(NetNoTemp);
   halfLen = round(len/2);
   NetNoTemp1 = NetNoTemp(1:halfLen);
   NetNoTemp2 = NetNoTemp(halfLen+1:len);
   tempMatrix1 = ICC_ISFC_Mat(NetNoTemp1,NetNoTemp1);%��������Ϊ����
   tempMatrix2 = ICC_ISFC_Mat(NetNoTemp2,NetNoTemp2);
   sumColumn1 = sum(tempMatrix1);%value
   sumColumn2 = sum(tempMatrix2);
    
   [sumColumn1,id1]  = sort(sumColumn1);
   [sumColumn2,id2]  = sort(sumColumn2,'descend');
   NetNoTempNew = NetNoTemp1(id1);
   NetNoTempNew = [NetNoTempNew;NetNoTemp2(id2)];
   ROI_No_New = [ROI_No_New;NetNoTempNew];
end

ICC_ISFC_Mat = ICC_ISFC_Mat(ROI_No_New, ROI_No_New); 
for i= 1:263
    for j=i+1:264
        ICC_ISFC_Mat(i,j) = NaN;
    end
end
 h=imagesc(ICC_ISFC_Mat); colorbar(); caxis([-0.3,0.8]);hold on;
colorbar( 'FontSize',10, 'fontname', 'arial','YTick',[-0.3:0.1:0.8]);
set(h,'alphadata',~isnan(ICC_ISFC_Mat));
%%
NetNoUnique = unique(NetNo); NetTmp = 1; 
for Count = 1 : ROI_NUM-1
    if(NetTmp < length(NetNoUnique))
        if(NetNo(ROI_No_New(Count)) == NetNoUnique(NetTmp) && NetNo(ROI_No_New(Count+1)) == NetNoUnique(NetTmp+1))
            Value = Count + 0.5;
%             plot([0:264], Value * ones(1,265), 'Color',[0.7 0.7 0.7], 'linewidth', 1);
%             plot(Value * ones(1,265), [0:264], 'Color',[0.7 0.7 0.7], 'linewidth', 1);
             if(NetTmp==1)
                plot([0:size(find(NetNo==NetTmp),1)], Value * ones(1,size(find(NetNo==NetTmp),1)+1), 'Color',[0.7 0.7 0.7], 'linewidth', 1);
                plot(Value * ones(1,264-size(find(NetNo==NetTmp),1)+1), [size(find(NetNo==NetTmp),1):264], 'Color',[0.7 0.7 0.7], 'linewidth', 1);
             end
             if(NetTmp==2)
                plot([0:size(find(NetNo==NetTmp|NetNo==1),1)], Value * ones(1,size(find(NetNo==NetTmp|NetNo==1),1)+1), 'Color',[0.7 0.7 0.7], 'linewidth', 1);
                plot(Value * ones(1,264-size(find(NetNo==NetTmp|NetNo==1),1)+1), [size(find(NetNo==NetTmp|NetNo==1),1):264], 'Color',[0.7 0.7 0.7], 'linewidth', 1);
             end
             if(NetTmp==3)
                plot([0:size(find(NetNo==NetTmp|NetNo==2|NetNo==1),1)], Value * ones(1,size(find(NetNo==NetTmp|NetNo==2|NetNo==1),1)+1), 'Color',[0.7 0.7 0.7], 'linewidth', 1);
                plot(Value * ones(1,264-size(find(NetNo==NetTmp|NetNo==2|NetNo==1),1)+1), [size(find(NetNo==NetTmp|NetNo==2|NetNo==1),1):264], 'Color',[0.7 0.7 0.7], 'linewidth', 1);
             end
             if(NetTmp==4)
                plot([0:size(find(NetNo==NetTmp|NetNo==3|NetNo==2|NetNo==1),1)], Value * ones(1,size(find(NetNo==NetTmp|NetNo==3|NetNo==2|NetNo==1),1)+1), 'Color',[0.7 0.7 0.7], 'linewidth', 1);
                plot(Value * ones(1,264-size(find(NetNo==NetTmp|NetNo==3|NetNo==2|NetNo==1),1)+1), [size(find(NetNo==NetTmp|NetNo==3|NetNo==2|NetNo==1),1):264], 'Color',[0.7 0.7 0.7], 'linewidth', 1);
             end
            if(NetTmp==5)
                plot([0:size(find(NetNo==NetTmp|NetNo==4|NetNo==3|NetNo==2|NetNo==1),1)], Value * ones(1,size(find(NetNo==NetTmp|NetNo==4|NetNo==3|NetNo==2|NetNo==1),1)+1), 'Color',[0.7 0.7 0.7], 'linewidth', 1);
                plot(Value * ones(1,264-size(find(NetNo==NetTmp|NetNo==4|NetNo==3|NetNo==2|NetNo==1),1)+1), [size(find(NetNo==NetTmp|NetNo==4|NetNo==3|NetNo==2|NetNo==1),1):264], 'Color',[0.7 0.7 0.7], 'linewidth', 1);
             end
            NetTmp = NetTmp + 1;
        end
    end
end

axis off;
text(-25.356,25.9474,'SMN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-26.2695,78.23,'DMN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-25.8581,131.7126,'CON','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-25.9987,177.4411,'VisN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-25.4732,217.77,'ALN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(-23.5763,249.0236,'FPN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');

text(14.8929,271.22,'SMN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(67.8692,271.22,'DMN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(119.5028,271.22,'CON','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(165.56,271.22,'VisN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(205.5616,271.22,'ALN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');
text(238.8837,271.22,'FPN','FontSize',11.5, 'fontname', 'arial', 'fontweight', 'bold');