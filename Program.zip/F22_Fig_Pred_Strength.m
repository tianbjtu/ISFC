clear;clc;
% %Fig4��B��
%strengthԤ�����
%   load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR160ROI_Strength %��Χ����[0,0.45]
%  XVarNames = {'Mov1','Mov2','Mov3','Mov4'};
%  matrixplot(MeanR, 'XVarNames', XVarNames, 'YVarNames', XVarNames, 'FillStyle', 'Fill', 'ColorBar', 'on');

%% �����ϵ�����󣬸��Ϸ�һ��������
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR160ROI_Strength;
% load D:\brainFingerprint\code\ISFCwork\Results\SubjInfo178_222Label_200507;
% LabelTmp = SubjInfo(:, 175);%41��CrystalIQ/175��Strength
% SubjNoUse = find(LabelTmp ~= -9999); 
% Strength = LabelTmp(SubjNoUse);
% %��ʵR 
% % 0.39 0.10 0.24 0.14
% % 0.16 0.27 0.15 0.12
% % 0.29 0.22 0.47 0.30
% % 0.18 0.18 0.29 0.34
% %����
% %69 1 12 4
% %1 46 21 33
% %5 13 7 3
% %18 11 10 13
% No = [69,1,12,4,1,46,21,33,5,13,7,3,18,11,10,13];
% for Mov1 = 1:4
%     for Mov2 = 1:4
%         Predicted1 = squeeze(Predicted(No((Mov1-1)*4+Mov2),Mov1,Mov2,:));
%         [r, p] = corrcoef (Strength, Predicted1);
%         R_Strength(Mov1,Mov2) = r(1,2);
%     end
% end
%  XVarNames = {'Mov1','Mov2','Mov3','Mov4'};
%  matrixplot(R_Strength, 'XVarNames', XVarNames, 'YVarNames', XVarNames, 'FillStyle', 'Fill', 'ColorBar', 'on');


% %% ɢ��ͼ
% figure('Position',[200 20 800 800]);box on; hold on;
% AxisMin = 60; AxisMax = 150;AxisLen = AxisMax - AxisMin; %�����X��Y�����Сֵ�����ֵ��x��y��һ����
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Strength;
% load D:\brainFingerprint\code\ISFCwork\Results\SubjInfo178_222Label_200507;
% LabelTmp = SubjInfo(:, 175);%41��CrystalIQ/175��Strength
% SubjNoUse = find(LabelTmp ~= -9999); 
% 
% Strength = LabelTmp(SubjNoUse);
% %��ʵR 
% %     0.3700    0.1700    0.3100    0.2500
% %     0.2100    0.4000    0.2600    0.2400
% %     0.3100    0.3000    0.4100    0.2600
% %     0.2500    0.2200    0.2300    0.3400
% % %����
% %8 16
% 
% Predicted = squeeze(Predicted(56,1,2,:));%M1-1:82;M1-2:56
% 
% [min([Strength, Predicted]) max([Strength, Predicted])]
% scrsz = get(0,'ScreenSize');
% set(gcf, 'color', 'white'); set(gca, 'color', 'white', 'LineWidth',2, 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% plot (Strength, Predicted, 'ks', 'LineWidth',2);%����
% B = regress (Predicted, [Strength, ones(length(Strength), 1)]);
% plot ([AxisMin+0.05*AxisMax:0.01:AxisMax*0.95], B(1)*[AxisMin+0.05*AxisMax:0.01:AxisMax*0.95]+B(2), 'r-', 'LineWidth', 4);%����Ǻ�ɫʵ�ߵ�
% axis([AxisMin AxisMax AxisMin AxisMax]);%����x��y��������Сֵ
% 
% %%here
% [P, S] = polyfit(Strength, Predicted, 1);
% x1 = [AxisMin+0.05*AxisLen:0.1:AxisMax-0.05*AxisLen]; 
% f = polyval(P, x1); plot (x1, f, 'r-', 'LineWidth', 4);
% [Y, delta] = polyconf (P, x1, S); 
% plot(x1, Y+delta, 'r--', 'LineWidth', 2); 
% plot(x1, Y-delta, 'r--', 'LineWidth', 2);
% %plot(x1, x1, 'k--','LineWidth', 2);
% 
% [r, p] = corrcoef (Strength, Predicted);
% text(AxisMax-0.2*(AxisMax-AxisMin)-6, AxisMax-0.04*(AxisMax-AxisMin), ['R = ', num2str(r(1,2), '%3.2f')], 'FontSize',19, 'fontname', 'times new roman', 'fontweight', 'bold');
% 
% RMSE = sqrt (sum ((Predicted - Strength) .^ 2 )/ (length(Strength)-1));
% text(AxisMax-0.2*(AxisMax-AxisMin)-6, AxisMax-0.08*(AxisMax-AxisMin), ['RMSE = ', num2str(RMSE, '%3.2f')], 'FontSize',19, 'fontname', 'times new roman', 'fontweight', 'bold');
% set(gca,'XTick',[AxisMin : 10 : AxisMax]); set(gca,'XTickLabel',[AxisMin : 10 : AxisMax]);
% set(gca,'YTick',[AxisMin : 10 : AxisMax]); set(gca,'YTickLabel',[AxisMin : 10 : AxisMax]);
% xlabel('Actual Strength', 'FontSize',19, 'fontname', 'times new roman', 'fontweight', 'bold');
% ylabel('Predicted Strength', 'FontSize',19, 'fontname', 'times new roman', 'fontweight', 'bold'); 
% % xlabel('Actual IQ', 'FontSize',19, 'fontname', 'arial', 'fontweight', 'bold');
% % ylabel('Predict IQ', 'FontSize',19, 'fontname', 'arial', 'fontweight', 'bold');

% %% ��״ͼ
% 
% clear;clc;
% MAX_Y = 1200;
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Strength.mat MeanR;
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_Perm5000_PLSR264ROI_Strength.mat;
% %��ʵR 
% %     0.3700    0.1700    0.3100    0.2500
% %     0.2100    0.4000    0.2600    0.2400
% %     0.3100    0.3000    0.4100    0.2600
% %     0.2500    0.2200    0.2300    0.3400
% Rtrue = 0.17;
% R_Perm = squeeze(R(:,1,2));
% Rmax = max(R_Perm);
% Rmin = min(R_Perm);
% 
% % A = [-0.3 : 0.05 : 0.5]; %%-----
% A = [ -0.4
%     -0.35
%     -0.30
%    -0.25
%    -0.20
%    -0.15
%    -0.10
%    -0.05
%     0
%     0.05
%     0.10
%     0.15
%     0.20
%     0.25
%     0.30
%     0.35
%     0.40
%     0.45
%     0.50]';
% for Tmp = 1 : length(A)
%     ACC_YY(Tmp) = sum ((R_Perm>=A(Tmp)-0.05) .* (R_Perm<A(Tmp))); %%-----
% end    
% %figure('Position',[100 20 1700 800]);box on; hold on;grid on; axis([-1.5 0.2 0 MAX_Y]); 
% figure('Position',[100 20 800 800]);box on; hold on;grid on; axis([-0.4 0.5 0 MAX_Y]); 
% set(gcf, 'color', 'white'); 
% set(gca, 'color', 'white', 'LineWidth',2, 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% % h = bar(A-0.01, ACC_YY, 0.9, 'b', 'LineWidth',2);
% h = bar(A-0.025, ACC_YY, 0.9,'FaceColor',[0.55 0.55 0.55], 'LineWidth',2);
% set(gca,'XTick',A); 
% set(gca,'XTickLabel',['']);
% set(gca,'YTick',[0 : 100: MAX_Y]); 
% set(gca,'YTickLabel',[0 : 100 : MAX_Y]);
% % for Tmp = 1 : length(A)
% %     if ACC_YY(Tmp)>=100
% %         text(A(Tmp)-0.045, ACC_YY(Tmp)+15, num2str(ACC_YY(Tmp)), 'fontsize',9, 'fontname', 'arial', 'fontweight', 'bold'); % 'bold'
% %     elseif ACC_YY(Tmp)>0
% %         text(A(Tmp)-0.04, ACC_YY(Tmp)+15, num2str(ACC_YY(Tmp)), 'fontsize',9, 'fontname', 'arial', 'fontweight', 'bold');
% %     end
% % end
% 
% % vec = [-0.3:0.1:0.5];
% % vec = [-0.4:0.01:0.5]; %%-----
% for Tmp = 1 : 1 : length(A)
%     for i = [-0.3, -0.2, -0.1, 0.0, 0.1, 0.2, 0.3, 0.4, 0.5] %%-----
%         if abs(A(Tmp)- i) < 10e-6
% %               text(A(Tmp), -1.1, num2str(A(Tmp)), 'fontsize',10, 'fontname', 'arial', 'fontweight', 'bold');
%                 num2str(A(Tmp))
%                 text(A(Tmp)-0.025,-25,num2str(A(Tmp),'%4.1f'), 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
%         end 
%     end
% end
% 
% 
%     
% %     if(A(Tmp)<-0.03)
% %         text(A(Tmp)-0.015, -2, strcat('R',num2str(A(Tmp))), 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% %     elseif (A(Tmp)>0.03)
% %         text(A(Tmp)-0.015, -2, strcat('R+',num2str(A(Tmp))), 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% %     else        
% %         text(A(Tmp)-0.005, -2, 'R', 'fontsize',12, 'fontname', 'arial', 'fontweight', 'bold');
% %     end
% 
% plot(Rtrue*ones(1,length(0.2:0.1:MAX_Y-0.2)), [0.2:0.1:MAX_Y-0.2], 'r.', 'LineWidth',2)
% 
% %xlabel('Correlations Based on 500 Permutations', 'FontSize',19, 'fontname', 'arial', 'fontweight', 'bold', 'Position', [-0.6, -3.9]);
% ylabel('Number of Correlation Coefficients', 'FontSize',19, 'fontname', 'times new roman', 'fontweight', 'bold'); 
% %xlabel('Correlation between the Estimated and Permuted Chronological Age', 'FontSize',16, 'fontname', 'arial', 'fontweight', 'bold'); 

%% P-value
% clear;clc;
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Strength.mat MeanR;%��ʵR
% load D:\brainFingerprint\code\ISFCwork\Results\Pred_Perm5000_PLSR264ROI_Strength.mat;
% Rture = [0.39,0.10,0.24,0.14,0.16,0.27,0.15,0.12,0.29,0.22,0.47,0.30,0.18,0.18,0.29,0.34];
% 
% for mov1 = 1:4
%     for mov2 = 1:4
%         A = squeeze(R(:,mov1,mov2));
%         N_High = sum(sum(A>MeanR(mov1,mov2))');
%         P_Value(mov1,mov2) = (1+N_High)/5001
%     end
% end
