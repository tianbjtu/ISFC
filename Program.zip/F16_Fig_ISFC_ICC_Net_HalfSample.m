%% Fig2(B)  ISFC��ICC�����ﻭ������������
load D:\brainFingerprint\code\ISFCwork\Results\ICC_Net_HalfSample.mat;
temp1 = ICC_NetMean_Mat;
load D:\brainFingerprint\code\ISFCwork\Results\ICC_Net_HalfSample_2.mat;
temp2 = ICC_NetMean_Mat;
ICC_NetMean_Mat = (temp1+temp2)/2;
XVarNames = {'SMN','DMN','CON','VisN','ALN','FPN'};
matrixplot(ICC_NetMean_Mat, 'XVarNames',XVarNames,'YVarNames',XVarNames, 'ColorBar', 'on');

%% ISFC��ICC������6*6������
% load D:\brainFingerprint\code\ISFCwork\Results\ICC_ISFC_FullTS ICC_ISFC_Mat;%160*160
% %��AP����Ļ���
% load D:\brainFingerprint\code\ISFCwork\Results\ROI_Net_7to6_200629.mat
% NetNo = ROI_160;
% NET_NUM = length(unique(NetNo));
% 
% CorrNetMean = zeros(NET_NUM, NET_NUM);
% for Tmp = 1 : NET_NUM
%     for Tmp2 = 1 : NET_NUM                     
%         A = ICC_ISFC_Mat(find(NetNo==Tmp), find(NetNo==Tmp2));   
%         CorrNetMean(Tmp, Tmp2) = mean(A(:));
%     end
% end

% XVarNames = {'SubcN','SMN','FPN','DMN','TempN','OccN'};%Ӧ��д��������
% matrixplot(CorrNetMean, 'XVarNames',XVarNames,'YVarNames',XVarNames, 'ColorBar', 'on');