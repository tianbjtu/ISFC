clear;clc;%ɾ��ʱ���͸���
OUTDIR = 'D:\brainFingerprint\code\ISFCwork\Results\';

INFile = 'D:\brainFingerprint\code\ISFCwork\Results\dataM1_264ROI'; 
load(INFile);
TimeNoUse1 = [24+5:267, 289+5:508, 530+5:717,738+5:801]+1;
dataM1 = dataM1(:,TimeNoUse1,:);
SampleNoUse1 = [1:65,67:123,125,127:129,131:134,136:182,184];
TS = dataM1(:,:,SampleNoUse1);
save(strcat(OUTDIR, 'Movie1_TS264'), 'TS');

INFile = 'D:\brainFingerprint\code\ISFCwork\Results\dataM2_264ROI'; 
load(INFile);
TimeNoUse2 = [24+5:250, 271+5:529, 549+5:798]+1;
dataM2 = dataM2(:,TimeNoUse2,:);
SampleNoUse2 = [1:65,67:123,125,127:129,131:181,183];
TS = dataM2(:,:,SampleNoUse2);
save(strcat(OUTDIR, 'Movie2_TS264'), 'TS');

INFile = 'D:\brainFingerprint\code\ISFCwork\Results\dataM3_264ROI'; 
load(INFile);
TimeNoUse3 = [24+5:203, 225+5:408, 429+5:632, 654+5:795]+1;
dataM3 = dataM3(:,TimeNoUse3,:);
SampleNoUse3 = [1:130,132:179];
TS = dataM3(:,:,SampleNoUse3);
save(strcat(OUTDIR, 'Movie3_TS264'), 'TS');

INFile = 'D:\brainFingerprint\code\ISFCwork\Results\dataM4_264ROI'; 
load(INFile);
TimeNoUse4 = [24+5:256, 276+5:505, 526+5:781]+1;
dataM4 = dataM4(:,TimeNoUse4,:);
SampleNoUse4 = [1:130,132:179];
TS = dataM4(:,:,SampleNoUse4);
save(strcat(OUTDIR, 'Movie4_TS264'), 'TS');
