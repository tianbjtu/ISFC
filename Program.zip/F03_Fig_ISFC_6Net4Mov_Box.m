clc;
clear;
ROI_NUM = 264;
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_178Subj;
CorrAllM = squeeze(mean(CorrMat264,2)); %4*178*264*264
% CorrMatMean = squeeze(mean(CorrAllM, 2)); %4*264*264
MovNum = size(CorrMat264,1);

load D:\brainFingerprint\code\ISFCwork\Results\AP6Clus210331.mat
NetNo = ROI_264;
NET_NUM = length(unique(NetNo));

for MovNo = 1: MovNum
    for Tmp1 = 1 : NET_NUM
        for Tmp2 = 1 : Tmp1
            NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);         
            Mat = zeros(ROI_NUM,ROI_NUM); 
            Mat(NetNo1, NetNo2) = 1; Mat(NetNo2,NetNo1) = 1;
            FEAT_NO = find(tril(Mat)); 

            Tmp = squeeze(CorrAllM(MovNo,:,:));%Tmp 178*25600,�޸������1-2/3/4��ò�ͬ��Ӱ��ͼ
%             Tmp = CorrMatMean;
            CorrNet{MovNo,Tmp1,Tmp2} = Tmp(FEAT_NO);
        end
    end
end

Net_11 = CorrNet{1,1,1};Net_12 = CorrNet{1,2,2};Net_13 = CorrNet{1,3,3};
Net_14 = CorrNet{1,4,4};Net_15 = CorrNet{1,5,5};Net_16 = CorrNet{1,6,6};

Net_21 = CorrNet{2,1,1};Net_22 = CorrNet{2,2,2};Net_23 = CorrNet{2,3,3};
Net_24 = CorrNet{2,4,4};Net_25 = CorrNet{2,5,5};Net_26 = CorrNet{2,6,6};

Net_31 = CorrNet{3,1,1};Net_32 = CorrNet{3,2,2};Net_33 = CorrNet{3,3,3};
Net_34 = CorrNet{3,4,4};Net_35 = CorrNet{3,5,5};Net_36 = CorrNet{3,6,6};

Net_41 = CorrNet{4,1,1};Net_42 = CorrNet{4,2,2};Net_43 = CorrNet{4,3,3};
Net_44 = CorrNet{4,4,4};Net_45 = CorrNet{4,5,5};Net_46 = CorrNet{4,6,6};


x = [Net_11;Net_21;Net_31;Net_41;...
    Net_12;Net_22;Net_32;Net_42;...
    Net_13;Net_23;Net_33;Net_43;...
    Net_14;Net_24;Net_34;Net_44;...
    Net_15;Net_25;Net_35;Net_45;...
    Net_16;Net_26;Net_36;Net_46];

g1 = repmat({'SMN_M1'},size(Net_11,1),1);g2 = repmat({'SMN_M2'},size(Net_21,1),1);
g3 = repmat({'SMN_M3'},size(Net_31,1),1);g4 = repmat({'SMN_M4'},size(Net_41,1),1);

g5 = repmat({'DMN_M1'},size(Net_12,1),1);g6 = repmat({'DMN_M2'},size(Net_22,1),1);
g7 = repmat({'DMN_M3'},size(Net_32,1),1);g8 = repmat({'DMN_M4'},size(Net_42,1),1);

g9 = repmat({'CON_M1'},size(Net_13,1),1);g10 = repmat({'CON_M2'},size(Net_23,1),1);
g11 = repmat({'CON_M3'},size(Net_33,1),1);g12 = repmat({'CON_M4'},size(Net_43,1),1);

g13 = repmat({'VisN_M1'},size(Net_14,1),1);g14 = repmat({'VisN_M2'},size(Net_24,1),1);
g15 = repmat({'VisN_M3'},size(Net_34,1),1);g16 = repmat({'VisN_M4'},size(Net_44,1),1);

g17 = repmat({'ALN_M1'},size(Net_15,1),1);g18 = repmat({'ALN_M2'},size(Net_25,1),1);
g19 = repmat({'ALN_M3'},size(Net_35,1),1);g20 = repmat({'ALN_M4'},size(Net_45,1),1);

g21 = repmat({'FPN_M1'},size(Net_16,1),1);g22 = repmat({'FPN_M2'},size(Net_26,1),1);
g23 = repmat({'FPN_M3'},size(Net_36,1),1);g24 = repmat({'FPN_M4'},size(Net_46,1),1);

g = [g1; g2; g3; g4; g5; g6; g7; g8; g9; g10; g11; g12; g13; g14; g15; g16; g17; g18; g19; g20; g21; g22; g23; g24];

figure('Position',[10 10 1030 420]);box on; hold on;
% hold on
% h = boxplot(Net_11,g1,'color','k','symbol','');
% h = boxplot(Net_21,g2,'color','g','symbol','');

h = boxplot(x,g,'color','k','symbol','');%,'LabelOrientation', 'inline'
%�����color��������ɫ�ģ��Ҵ�ŵ���һ�£��������㲻��ϲ����Щ��ɫ�����ԾͿ�����ô����ͬһ���һ����ɫ�Ϳ���
% color = [1,1,0;1,1,0; 1,1,0;1,1,0;...
%     0,1,1;0,1,1;0,1,1;0,1,1;...
%     0.25,0.878,0.51;0.25,0.878,0.51;0.25,0.878,0.51;0.25,0.878,0.51;...
%     0,0.74902,1;0,0.74902,1;0,0.74902,1;0,0.74902,1;...
%     0,0,1;0,0,1;0,0,1;0,0,1;...
%     0.09,0.09,0.439;0.09,0.09,0.439;0.09,0.09,0.439;0.09,0.09,0.439;...    
%    ];
color = [0.97,0.96,0.11;0.97,0.96,0.11;0.97,0.96,0.11;0.97,0.96,0.11;...
    1,0.74,0.24;1,0.74,0.24;1,0.74,0.24;1,0.74,0.24;...
    0.62,0.78,0.27;0.62,0.78,0.27;0.62,0.78,0.27;0.62,0.78,0.27;...
    0.04,0.74,0.74;0.04,0.74,0.74;0.04,0.74,0.74;0.04,0.74,0.74;...
    0.27,0.37,0.97; 0.27,0.37,0.97; 0.27,0.37,0.97; 0.27,0.37,0.97;...
    0.24,0.15,0.66;0.24,0.15,0.66;0.24,0.15,0.66;0.24,0.15,0.66;...    
   ];
h1 = findobj(gca,'Tag','Box');
for j=1:length(h1)
   patch(get(h1(j),'XData'),get(h1(j),'YData'),color(j,:),'FaceAlpha',.5);
end

% h.Parent.XAxis.TickLabelRotation = 45;
obj = get(h,'children');
set(h,'LineWidth',1.5);

ylim([-0.2,0.6]);
% set(gca,'YTicklabel',{'0','10%','20%','30%','40%','50%','60%','70%','80%','90%'});
set(gca,'LineWidth',1.5, 'fontsize',10, 'fontname', 'arial', 'fontweight', 'bold');
xtickangle(45)
ylabel('ISFCs', 'FontSize',19, 'fontname', 'times new roman', 'fontweight', 'bold'); 