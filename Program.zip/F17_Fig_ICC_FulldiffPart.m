load D:\brainFingerprint\code\ISFCwork\Results\ICC_Net_FullTS.mat;
tmp1 = roundn(ICC_NetMean_Mat,-2);
load D:\brainFingerprint\code\ISFCwork\Results\ICC_Net_PartTS.mat;
tmp2 = roundn(ICC_NetMean_Mat,-2);
tmp = tmp1-tmp2;
XVarNames = {'SMN','DMN','CON','VisN','ALN','FPN'};
matrixplot(tmp, 'XVarNames',XVarNames,'YVarNames',XVarNames, 'ColorBar', 'on');

