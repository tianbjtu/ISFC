%ISFC����Net
clear;clc;
ROI_NUM = 264;

%ISFC
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_12Part_178Subj; % CorrMat 4*178*25600 CorrMat160 4*178*160*160

% CorrMatMean = squeeze(mean(CorrMat160,2));
CorrAllM = squeeze(mean(CorrMat264,2)); CorrMatMean = squeeze(mean(CorrAllM, 1)); 
MovNum = size(CorrMat264,1);

%% ��AP����Ļ���
load D:\brainFingerprint\code\ISFCwork\Results\AP6Clus210331.mat
NetNo = ROI_264;
NET_NUM = length(unique(NetNo));

%% ȫ�����������ǣ���F02_useA03dataһ�¡�
CorrNetMean = zeros(NET_NUM, NET_NUM);
for Tmp1 = 1 : NET_NUM
    for Tmp2 = 1 : Tmp1
        NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);         
        Mat = zeros(ROI_NUM,ROI_NUM); 
        Mat(NetNo1, NetNo2) = 1; Mat(NetNo2,NetNo1) = 1;
        FEAT_NO = find(tril(Mat)); 
       
%         Tmp = squeeze(CorrMatMean(4,:,:));%Tmp 178*25600,�޸������1-2/3/4��ò�ͬ��Ӱ��ͼ
        Tmp = CorrMatMean;
        Tmp3 = Tmp(FEAT_NO);% 178*������
        CorrNetMean(Tmp1,Tmp2) = mean(Tmp3(:));
    end
end

%%
XVarNames = {'SMN','DMN','CON','VisN','ALN','FPN'};
matrixplot(CorrNetMean, 'XVarNames',XVarNames,'YVarNames',XVarNames,'ColorBar','on'); 