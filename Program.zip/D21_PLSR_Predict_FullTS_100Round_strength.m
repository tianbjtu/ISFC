%% Ԥ�⾫��-5%��10%��....100% ISFC�����ߡ�

FOLD_NUM = 10; DIM = 10; ROUND_NUM = 100;%DIM��Ϊ10
load D:\brainFingerprint\code\ISFCwork\Results\SubjInfo178_222Label_200507;
LabelTmp = SubjInfo(:, 175);%2/41 �Ա�/����+175%%%--------Gender 2 Age 220 IQ 38/39 CrystalIQ 40/41 Reading 13/14 PictVoc 15/16 Strength 174/175 
SubjNoUse = find(LabelTmp ~= -9999); Label = LabelTmp(SubjNoUse); SampleSize = length(Label);

%Ϊ��ͳһ����ƽ��ֵ����
load D:\brainFingerprint\code\ISFCwork\Results\CorrArray_All4Mov_178Subj CorrMat;
CorrMat_Mov = squeeze(mean(CorrMat,1));CorrMatMean = squeeze(mean(CorrMat_Mov,1));
[SortedISFC,Pos] = sort(abs(CorrMatMean),'descend');
CorrNum = size(CorrMatMean,2);
CorrMatUse = CorrMat(:,SubjNoUse,Pos);%����С˳������

for step = 5:5:100
    step
    %ȡisfc
    Num_Strong = round(CorrNum*step/100);
    CorrMat = CorrMatUse(:,:,[1:Num_Strong]);
    %% Ԥ��
    for RoundNo = 1 : ROUND_NUM
    RoundNo;
    [TrainNo, TestNo, Permed] = f_NFold(SampleSize, FOLD_NUM);
    for MovNo = 1 : 4
        for FoldNo = 1 : FOLD_NUM
            LabelTrain = Label(TrainNo{FoldNo}, :);
            CorrTrain = squeeze(CorrMat(MovNo, TrainNo{FoldNo}, :));
        
            LabelMean = mean(LabelTrain, 1); 
            CorrMean = mean(CorrTrain, 1);
            [XLOADINGS,YLOADINGS,XSCORES,YSCORES, Beta] = plsregress(CorrTrain, LabelTrain, DIM);
        
            for MovTargNo = 1 : 4
                CorrTest = squeeze(CorrMat(MovTargNo, TestNo{FoldNo}, :)); 
                CorrTest_Norm = CorrTest - repmat(CorrMean, size(CorrTest, 1), 1); 
                B = Beta(2:end, :);
                TestLabel_Pred = CorrTest_Norm * B;
            
                Predicted(RoundNo, MovNo, MovTargNo, TestNo{FoldNo}) = TestLabel_Pred + repmat(LabelMean, size(TestLabel_Pred, 1), 1);
            end 
        end    
    
        %%
        for MovTargNo = 1 : 4
            if (length(unique(int16(Label))) == 2)
                R(RoundNo, MovNo, MovTargNo) = sum(abs((squeeze(Predicted(RoundNo, MovNo, MovTargNo, :)) > 0.5) - Label) < 0.000001) / SampleSize;
            else
                r = corrcoef(squeeze(Predicted(RoundNo, MovNo, MovTargNo, :)), Label);
                R(RoundNo, MovNo, MovTargNo) = r(1,2); 
                RMSE(RoundNo, MovNo, MovTargNo) = sqrt (sum ((squeeze(Predicted(RoundNo, MovNo, MovTargNo, :)) - Label) .^ 2) / (SampleSize-1)); 
            end
        end
    end    
    
    MeanR = squeeze(mean(R, 1));
    StdR = squeeze(std(R, 1));
    end
    R_Curve(step/5,:,:) = MeanR;
end
    