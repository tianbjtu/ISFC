load D:\brainFingerprint\code\ISFCwork\Results\ICC_Net_FullTS.mat;
tmp1 = roundn(ICC_NetMean_Mat,-2);
load D:\brainFingerprint\code\ISFCwork\Results\ICC_Net_HalfSample.mat;
tmp2 = ICC_NetMean_Mat;
load D:\brainFingerprint\code\ISFCwork\Results\ICC_Net_HalfSample_2.mat;
tmp3 = ICC_NetMean_Mat;
tmp4 = roundn((tmp2+tmp3)/2,-2);

tmp = tmp1-tmp4;
XVarNames = {'SMN','DMN','CON','VisN','ALN','FPN'};
matrixplot(tmp, 'XVarNames',XVarNames,'YVarNames',XVarNames, 'ColorBar', 'on');