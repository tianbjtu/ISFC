clear;clc;
% Strength-accuracy��16 line 
%%
load D:\brainFingerprint\code\ISFCwork\Results\Pred_PLSR264ROI_Strength_StrongCorr;


for RoundNo = 1:size(R_Curve,1)
     Temp = squeeze(R_Curve(RoundNo,:,:));
        for i = 1:4
         for j = 1:4
            dimR(RoundNo,4*(i-1)+j) = Temp(i,j);
         end
     end
end

%% StrengthԤ��16������ͼ
x = 1:1:20;
figure('Position',[100 0 900 750]);box on; hold on;
scrsz = get(0, 'ScreenSize');
% plot(x,dimR(:,1),'-oy',x,dimR(:,2),'-og',x,dimR(:,3),'-ob',x,dimR(:,4),'-oc',x,dimR(:,5),'-ok',x,dimR(:,6),'-or', x,dimR(:,7),'-om','LineWidth',1.8);
% plot(x,dimR(:,8),'-o','color',[0.5,0.4,0.8],'LineWidth',1.8);
% plot(x,dimR(:,9),'-o','color',[0,0.7,1],'LineWidth',1.8);
% plot(x,dimR(:,10),'-o','color',[0.8,0.4,0.8],'LineWidth',1.8);
% plot(x,dimR(:,11),'-o','color',[0,1,0.5],'LineWidth',1.8);
% plot(x,dimR(:,12),'-o','color',[0.4,0.5,0.1],'LineWidth',1.8);
% plot(x,dimR(:,13),'-o','color',[1,0.8,0],'LineWidth',1.8);
% plot(x,dimR(:,14),'-o','color',[1,0.5,0],'LineWidth',1.8);
% plot(x,dimR(:,15),'-o','color',[1,0.3,0],'LineWidth',1.8);
% plot(x,dimR(:,16),'-o','color',[0.5,0.7,0.2],'LineWidth',1.8);
plot(x,dimR(:,1),'-o','color',[0.85,0.33,0.1],'LineWidth',1.8,'MarkerFaceColor',[0.85,0.33,0.1]);
plot(x,dimR(:,2),'-s','color',[0.99,0.88,0.55],'LineWidth',1.8);
plot(x,dimR(:,3),'-s','color',[0.99,0.88,0.55],'LineWidth',1.8);
plot(x,dimR(:,4),'-s','color',[0.99,0.88,0.55],'LineWidth',1.8);

plot(x,dimR(:,5),'-s','color',[1,0.75294,0.79608],'LineWidth',1.8);
plot(x,dimR(:,6),'-o','color',[1,0,0],'LineWidth',1.8,'MarkerFaceColor',[1,0,0]);
plot(x,dimR(:,7),'-s','color',[1,0.75294,0.79608],'LineWidth',1.8);
plot(x,dimR(:,8),'-s','color',[1,0.75294,0.79608],'LineWidth',1.8);


plot(x,dimR(:,9),'-s','color',[0.60392,0.80392,0.119608],'LineWidth',1.8);
plot(x,dimR(:,10),'-s','color',[0.60392,0.80392,0.119608],'LineWidth',1.8);
%plot(x,dimR(:,11),'-o','color',[0.13333,0.5451,0.13333],'LineWidth',1.8);
plot(x,dimR(:,11),'-o','color',[0.18,0.31,0.01],'LineWidth',1.8,'MarkerFaceColor',[0.18,0.31,0.01]);
plot(x,dimR(:,12),'-s','color',[0.60392,0.80392,0.119608],'LineWidth',1.8);


plot(x,dimR(:,13),'-s','color',[0,0.74902,1],'LineWidth',1.8);
plot(x,dimR(:,14),'-s','color',[0,0.74902,1],'LineWidth',1.8);
plot(x,dimR(:,15),'-s','color',[0,0.74902,1],'LineWidth',1.8);
%plot(x,dimR(:,16),'-o','color',[0.11765,0.56471,1],'LineWidth',1.8);
plot(x,dimR(:,16),'-o','color',[0,0,1],'LineWidth',1.8,'MarkerFaceColor',[0,0,1]);

set(gcf, 'color', 'white'); set(gca, 'color', 'white', 'LineWidth',2, 'fontsize',16, 'fontname', 'arial', 'fontweight', 'bold');
xlim([0,21]);
set(gca,'XTick',[0:1:21])
set(gca,'XTicklabel',{'','','10%','','20%','','30%','','40%','','50%','','60%','','70%','','80%','','90%','','100%',''});% 100%�ľ����滻һ��
ylim([0,0.5]);
set(gca,'YTick',[0:0.05:0.5]) %
set(gca,'YTicklabel',{'0','0.05','0.10','0.15','0.20','0.25','0.30','0.35','0.40','0.45','0.50','0.55','0.60'})


legend('M1-M1','M1-M2','M1-M3','M1-M4','M2-M1','M2-M2','M2-M3','M2-M4','M3-M1','M3-M2','M3-M3','M3-M4','M4-M1','M4-M2','M4-M3','M4-M4','location','northeastOutside');
set(gca,'fontweight', 'bold','Linewidth',2) %
xlabel('Percentage of ISFCs', 'FontSize',24, 'fontname', 'times new roman', 'fontweight', 'bold');
ylabel('Correlation Coefficient', 'FontSize',24, 'fontname', 'times new roman', 'fontweight', 'bold'); 